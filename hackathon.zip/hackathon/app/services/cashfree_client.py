import base64
import hashlib
import hmac
import json
import logging
from typing import Any, Dict, Optional

import httpx


LOGGER = logging.getLogger(__name__)


class CashfreeAPIError(Exception):
    def __init__(self, message: str, status_code: int = 500) -> None:
        super().__init__(message)
        self.status_code = status_code


class CashfreeClient:
    API_VERSION = "2023-08-01"

    def __init__(self, app_id: str, secret_key: str, environment: str = "SANDBOX") -> None:
        self.app_id = app_id
        self.secret_key = secret_key
        self.environment = (environment or "SANDBOX").upper()
        self.base_url = (
            "https://sandbox.cashfree.com/pg"
            if self.environment == "SANDBOX"
            else "https://api.cashfree.com/pg"
        )

    @property
    def is_configured(self) -> bool:
        return bool(self.app_id and self.secret_key)

    @property
    def headers(self) -> Dict[str, str]:
        return {
            "x-client-id": self.app_id,
            "x-client-secret": self.secret_key,
            "x-api-version": self.API_VERSION,
            "content-type": "application/json",
            "accept": "application/json",
        }

    async def request(self, method: str, path: str, json_payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        if not self.is_configured:
            raise CashfreeAPIError("Cashfree credentials are not configured", status_code=500)

        url = f"{self.base_url}{path}"
        try:
            async with httpx.AsyncClient(timeout=25.0) as client:
                response = await client.request(method=method, url=url, headers=self.headers, json=json_payload)
        except httpx.RequestError as exc:
            LOGGER.error("Cashfree request error for %s %s: %s", method, path, exc)
            raise CashfreeAPIError("Unable to reach Cashfree API", status_code=502) from exc

        if response.status_code >= 400:
            detail = response.text
            LOGGER.error("Cashfree API failure (%s %s): %s", response.status_code, path, detail)
            try:
                payload = response.json()
            except json.JSONDecodeError:
                payload = {}

            message = str(payload.get("message") or detail)
            if response.status_code == 403 and "ip address is not allowed" in message.lower():
                message = (
                    "Cashfree blocked this request because your server public IP is not allowlisted. "
                    "Add your public IP in Cashfree dashboard API allowlist, or disable IP restriction for sandbox."
                )

            raise CashfreeAPIError(
                f"Cashfree API error ({response.status_code}): {message}",
                status_code=response.status_code,
            )

        return response.json()

    async def create_order(
        self,
        order_id: str,
        order_amount: float,
        customer_id: str,
        customer_name: str,
        customer_email: str,
        customer_phone: str,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {
            "order_id": order_id,
            "order_amount": round(order_amount, 2),
            "order_currency": "INR",
            "customer_details": {
                "customer_id": customer_id,
                "customer_name": customer_name,
                "customer_email": customer_email,
                "customer_phone": customer_phone,
            },
            "order_note": "Spheronix Hackathon Registration",
        }
        return await self.request("POST", "/orders", json_payload=payload)

    async def fetch_order_payments(self, order_id: str) -> Dict[str, Any]:
        return await self.request("GET", f"/orders/{order_id}/payments")

    def verify_webhook_signature(self, raw_body: bytes, webhook_signature: str) -> bool:
        if not webhook_signature:
            return False

        normalized_signature = webhook_signature.strip().replace("sha256=", "")
        digest = hmac.new(self.secret_key.encode("utf-8"), raw_body, hashlib.sha256).digest()
        expected_base64 = base64.b64encode(digest).decode("utf-8")
        expected_hex = digest.hex()
        return hmac.compare_digest(normalized_signature, expected_base64) or hmac.compare_digest(
            normalized_signature, expected_hex
        )
