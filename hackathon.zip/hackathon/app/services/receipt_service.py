import io
from datetime import datetime
from typing import Any, Dict
from urllib.parse import quote

from itsdangerous import BadSignature, URLSafeSerializer

from app.core.time_utils import ensure_ist, format_ist, utc_now
from config.settings import get_settings

settings = get_settings()
serializer = URLSafeSerializer(settings.secret_key, salt="receipt-download")


def format_datetime_ist(value: Any) -> str:
    if isinstance(value, datetime):
        return ensure_ist(value).strftime("%Y-%m-%d %H:%M:%S IST")
    return str(value)


def create_receipt_token(registration_id: str, email: str) -> str:
    return serializer.dumps({"registration_id": registration_id, "email": email.lower()})


def verify_receipt_token(token: str, registration_id: str, email: str) -> bool:
    try:
        payload = serializer.loads(token)
    except BadSignature:
        return False

    return (
        payload.get("registration_id") == registration_id
        and payload.get("email") == email.lower()
    )


def build_receipt_download_url(registration_id: str, email: str) -> str:
    token = create_receipt_token(registration_id, email)
    # Defensively clean the base URL: strip comments, whitespace, trailing slashes,
    # and take only the first entry if a comma-separated list was accidentally configured.
    raw_base = settings.app_base_url or "http://127.0.0.1:8000"
    raw_base = raw_base.split("#")[0].strip()           # remove inline comments
    raw_base = raw_base.split(",")[0].strip()           # take only first URL if list
    base = raw_base.rstrip("/")
    safe_email = quote(email)
    safe_token = quote(token)
    return f"{base}/api/receipt/{registration_id}?email={safe_email}&token={safe_token}"


def build_receipt_pdf(registration_doc: Dict[str, Any], recipient_email: str) -> bytes:
    payment = registration_doc.get("payment", {})
    leader = registration_doc.get("leader", {})

    registration_id = registration_doc.get("cf_order_id", "N/A")
    mode = str(registration_doc.get("participationMode", "individual")).title()
    team_name = registration_doc.get("team_name") or "N/A"
    team_id = registration_doc.get("team_id") or "N/A"
    transaction_id = payment.get("transaction_id") or "N/A"
    amount = float(payment.get("amount") or 0)
    currency = payment.get("currency") or "INR"
    status = str(payment.get("status") or "success").upper()

    timestamp = payment.get("timestamp") or registration_doc.get("registeredAt") or utc_now()
    paid_at = format_datetime_ist(timestamp)

    generated_on = format_ist(utc_now())
    registration_rows = [
        ("Registration ID", registration_id),
        ("Mode", mode),
        ("Leader Name", str(leader.get("name", "N/A"))),
        ("Leader Email", str(leader.get("email", "N/A"))),
        ("Recipient Email", recipient_email),
    ]
    if team_name != "N/A":
        registration_rows.append(("Team Name", team_name))
    if team_id != "N/A":
        registration_rows.append(("Team ID", team_id))

    payment_rows = [
        ("Transaction ID", transaction_id),
        ("Amount Paid", f"{currency} {amount:.2f}"),
        ("Payment Status", status),
        ("Payment Date", paid_at),
        ("Payment Gateway", "CASHFREE"),
    ]
    return _build_professional_pdf(generated_on, registration_rows, payment_rows)


def _pdf_escape(text: str) -> str:
    return text.replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")


def _build_professional_pdf(
    generated_on: str,
    registration_rows: list[tuple[str, str]],
    payment_rows: list[tuple[str, str]],
) -> bytes:
    commands: list[str] = []

    # Header background
    commands.extend([
        "0.09 0.25 0.59 rg",
        "40 760 515 60 re f",
    ])

    # Header text
    commands.extend([
        "BT",
        "/F2 20 Tf",
        "1 1 1 rg",
        "58 795 Td",
        "(Spheronix Hackathon 2026) Tj",
        "ET",
        "BT",
        "/F1 11 Tf",
        "0.86 0.91 1 rg",
        "58 778 Td",
        "(Official Payment Receipt) Tj",
        "ET",
        "BT",
        "/F1 10 Tf",
        "0.86 0.91 1 rg",
        "380 778 Td",
        f"(Generated: {_pdf_escape(generated_on)}) Tj",
        "ET",
    ])

    # Registration card
    commands.extend([
        "0.96 0.97 1 rg",
        "40 545 515 195 re f",
        "0.85 0.89 0.97 RG",
        "1 w",
        "40 545 515 195 re S",
        "BT",
        "/F2 13 Tf",
        "0.12 0.16 0.24 rg",
        "55 720 Td",
        "(Registration Details) Tj",
        "ET",
    ])

    y = 700
    for label, value in registration_rows:
        safe_label = _pdf_escape(label)
        safe_value = _pdf_escape(value)
        commands.extend([
            "BT",
            "/F2 10 Tf",
            "0.2 0.24 0.33 rg",
            f"55 {y} Td",
            f"({safe_label}:) Tj",
            "ET",
            "BT",
            "/F1 10 Tf",
            "0.11 0.14 0.2 rg",
            f"180 {y} Td",
            f"({safe_value}) Tj",
            "ET",
        ])
        y -= 18

    # Payment card
    commands.extend([
        "0.95 0.99 0.97 rg",
        "40 350 515 170 re f",
        "0.8 0.93 0.87 RG",
        "1 w",
        "40 350 515 170 re S",
        "BT",
        "/F2 13 Tf",
        "0.08 0.26 0.2 rg",
        "55 500 Td",
        "(Payment Details) Tj",
        "ET",
    ])

    y = 480
    for label, value in payment_rows:
        safe_label = _pdf_escape(label)
        safe_value = _pdf_escape(value)
        commands.extend([
            "BT",
            "/F2 10 Tf",
            "0.16 0.29 0.24 rg",
            f"55 {y} Td",
            f"({safe_label}:) Tj",
            "ET",
            "BT",
            "/F1 10 Tf",
            "0.1 0.2 0.16 rg",
            f"180 {y} Td",
            f"({safe_value}) Tj",
            "ET",
        ])
        y -= 20

    commands.extend([
        "BT",
        "/F1 10 Tf",
        "0.35 0.39 0.46 rg",
        "55 320 Td",
        "(This is a system-generated receipt and serves as official proof of payment.) Tj",
        "ET",
        "BT",
        "/F2 10 Tf",
        "0.25 0.29 0.35 rg",
        "55 300 Td",
        "(Spheronix Hackathon Team) Tj",
        "ET",
    ])

    stream_data = "\n".join(commands).encode("latin-1", errors="replace")

    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>",
        b"<< /Length " + str(len(stream_data)).encode("ascii") + b" >>\nstream\n" + stream_data + b"\nendstream",
    ]

    buffer = io.BytesIO()
    buffer.write(b"%PDF-1.4\n")

    offsets = [0]
    for idx, obj in enumerate(objects, start=1):
        offsets.append(buffer.tell())
        buffer.write(f"{idx} 0 obj\n".encode("ascii"))
        buffer.write(obj)
        buffer.write(b"\nendobj\n")

    xref_pos = buffer.tell()
    buffer.write(f"xref\n0 {len(objects) + 1}\n".encode("ascii"))
    buffer.write(b"0000000000 65535 f \n")
    for pos in offsets[1:]:
        buffer.write(f"{pos:010d} 00000 n \n".encode("ascii"))

    buffer.write(
        (
            "trailer\n"
            f"<< /Size {len(objects) + 1} /Root 1 0 R >>\n"
            "startxref\n"
            f"{xref_pos}\n"
            "%%EOF"
        ).encode("ascii")
    )
    return buffer.getvalue()
