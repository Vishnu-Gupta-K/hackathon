import json
import logging
import re
from pathlib import Path

from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import MongoClient
from pymongo.errors import OperationFailure

from config.settings import get_settings

settings = get_settings()
logger = logging.getLogger(__name__)

MONGO_URI = settings.effective_mongodb_uri
DB_NAME = settings.effective_database_name

sync_client = MongoClient(MONGO_URI)
sync_db = sync_client[DB_NAME]

async_client = AsyncIOMotorClient(MONGO_URI)
async_db = async_client[DB_NAME]
GLOBAL_DB_NAME = "HackathonSpheronixGlobal"
global_async_db = async_client[GLOBAL_DB_NAME]
global_sync_db = sync_client[GLOBAL_DB_NAME]

users_collection = sync_db["users"]
students_collection = sync_db["registrations"]
registrations_collection = sync_db["registrations"]
teams_collection = sync_db["teams"]
colleges_collection = global_sync_db["colleges"]
contacts_collection = global_sync_db["contacts"]
hackathon_challenges_collection = sync_db["hackathon_challenges"]

users_async_collection = async_db["users"]
registrations_async_collection = async_db["registrations"]
teams_async_collection = async_db["teams"]
colleges_async_collection = global_async_db["colleges"]
hackathon_challenges_async_collection = async_db["hackathon_challenges"]
global_data_async_collection = global_async_db["global data"]
branches_async_collection = global_async_db["branches"]
contacts_async_collection = global_async_db["contacts"]

def initialize_sync_collections() -> None:
    users_collection.create_index("email", unique=True)
    registrations_collection.create_index("email", unique=True)
    registrations_collection.create_index("mobile", unique=True)
    registrations_collection.create_index("rollNumber", unique=True, sparse=True)
    registrations_collection.create_index("cf_order_id", unique=True, sparse=True)
    teams_collection.create_index("teamId", unique=True)
    colleges_collection.create_index("name", unique=True)
    colleges_collection.create_index("name_lc")
    colleges_collection.create_index("sort_order")
    contacts_collection.create_index("email")
    contacts_collection.create_index("timestamp")
    hackathon_challenges_collection.create_index("difficulty")


async def initialize_async_collections() -> None:
    # Cleanup legacy unique index on participant_id if it exists.
    # We no longer want participant_id to be unique before it's assigned,
    # and the existing unique index (not sparse) prevents multiple nulls.
    try:
        await registrations_async_collection.drop_index("participant_id_1")
        logger.info("Dropped legacy index 'participant_id_1' from registrations collection")
    except OperationFailure:
        # Index doesn't exist, which is fine
        pass

    await users_async_collection.create_index("email", unique=True)
    await registrations_async_collection.create_index("email", unique=True)
    await registrations_async_collection.create_index("mobile", unique=True)
    await registrations_async_collection.create_index("rollNumber", unique=True, sparse=True)
    await registrations_async_collection.create_index("cf_order_id", unique=True, sparse=True)
    await teams_async_collection.create_index("teamId", unique=True)
    await colleges_async_collection.create_index("name_lc")
    await colleges_async_collection.create_index("sort_order")
    await contacts_async_collection.create_index("email")
    await contacts_async_collection.create_index("timestamp")
    await hackathon_challenges_async_collection.create_index([("category", 1), ("title", 1)], unique=True)
    await hackathon_challenges_async_collection.create_index("category")
    await hackathon_challenges_async_collection.create_index("difficulty")