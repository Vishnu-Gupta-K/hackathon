import logging
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.middleware.sessions import SessionMiddleware
from uvicorn.middleware.proxy_headers import ProxyHeadersMiddleware

from app.core.logging_utils import configure_logging
from app.core.time_utils import ist_timestamp
from app.database.mongodb import initialize_async_collections
from app.routers import auth, colleges, payments, students, teams, tasks, contacts, exports
from config.settings import get_settings

settings = get_settings()

configure_logging(level=logging.INFO)


@asynccontextmanager
async def lifespan(_: FastAPI):
    await initialize_async_collections()
    yield


app = FastAPI(title=settings.app_name, lifespan=lifespan)

app.add_middleware(
    SessionMiddleware,
    secret_key=settings.secret_key,
    same_site="lax",
    https_only=settings.is_production,
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(ProxyHeadersMiddleware, trusted_hosts=["*"])


@app.middleware("http")
async def add_security_headers(request: Request, call_next):
    response = await call_next(request)
    path = request.url.path
    # The OAuth callback popup page MUST have "unsafe-none" so it can:
    # 1. Access window.opener to call postMessage()
    # 2. Call window.close() to close itself
    # All OTHER pages get "same-origin-allow-popups" so they can open
    # and receive messages from the Google OAuth popup.
    if path.startswith("/api/auth/"):
        response.headers["Cross-Origin-Opener-Policy"] = "unsafe-none"
    else:
        response.headers["Cross-Origin-Opener-Policy"] = "same-origin-allow-popups"
    return response


@app.exception_handler(Exception)
async def unhandled_exception_handler(_: Request, exc: Exception):
    logging.getLogger("app").exception("Unhandled exception: %s", exc)
    return JSONResponse(
        status_code=500,
        content={
            "detail": "Internal server error",
            "timestamp": ist_timestamp(),
        },
    )


@app.get("/")
async def read_root():
    return RedirectResponse(url="/new_landing.html")


@app.get("/api/health")
def health_check():
    return {
        "status": "running",
        "timestamp": ist_timestamp(),
        "environment": settings.app_env,
        "timezone": "Asia/Kolkata",
    }


app.include_router(auth.router)
app.include_router(colleges.router)
app.include_router(payments.router)
app.include_router(students.router)
app.include_router(teams.router)
app.include_router(tasks.router)
app.include_router(contacts.router)
app.include_router(exports.router)

# Serve static files at root
static_app = StaticFiles(directory="static", html=True)

async def static_handler(scope, receive, send):
    if scope["type"] != "http":
        if scope["type"] == "websocket":
            await send({"type": "websocket.close", "code": 1000})
        return
    await static_app(scope, receive, send)

app.mount("/", static_handler, name="static")


if __name__ == "__main__":
    uvicorn.run("app.main:app", host=settings.server_host, port=settings.server_port, reload=False)
