from fastapi import APIRouter, Header, HTTPException, Request

from app.core.time_utils import utc_now
from app.database.mongodb import registrations_async_collection
from app.models.schemas import PaymentOrderRequest, PaymentVerification
from app.services.payment_service import cashfree_client, create_order, verify_cashfree_payment

router = APIRouter(prefix="/api/payment", tags=["payments"])


@router.post("/order")
async def create_payment_order(request: PaymentOrderRequest):
    return await create_order(request)


@router.post("/verify")
async def verify_payment(data: PaymentVerification):
    try:
        existing = await registrations_async_collection.find_one(
            {"cf_order_id": data.cf_order_id},
            {"_id": 0, "payment.mock_mode": 1},
        )
        existing_payment = existing.get("payment", {}) if existing else {}
        existing_mock_mode = bool(existing_payment.get("mock_mode"))

        verified_payment = await verify_cashfree_payment(data.cf_order_id, data.cf_payment_id)
        cf_payment_id = (
            verified_payment.get("cf_payment_id")
            or verified_payment.get("payment_id")
            or verified_payment.get("paymentId")
        )
        payment_status = str(verified_payment.get("payment_status", "SUCCESS")).lower()

        await registrations_async_collection.update_one(
            {"cf_order_id": data.cf_order_id},
            {
                "$set": {
                    "cf_order_id": data.cf_order_id,
                    "payment": {
                        "gateway": "cashfree",
                        "transaction_id": cf_payment_id,
                        "amount": verified_payment.get("payment_amount"),
                        "currency": verified_payment.get("payment_currency") or "INR",
                        "status": payment_status,
                        "mock_mode": existing_mock_mode,
                        "timestamp": utc_now(),
                    },
                    "verifiedAt": utc_now(),
                    "updatedAt": utc_now(),
                    "password": "",
                    "feedback": "",
                    "github_link": "",
                },
                "$setOnInsert": {"createdAt": utc_now()},
            },
            upsert=True,
        )

        return {
            "status": "success",
            "message": "Payment verified successfully",
            "cf_order_id": data.cf_order_id,
            "cf_payment_id": cf_payment_id,
        }
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Payment verification error: {exc}")


@router.post("/webhook")
async def cashfree_webhook(
    request: Request,
    x_webhook_signature: str | None = Header(default=None, alias="x-webhook-signature"),
):
    raw_body = await request.body()
    if not x_webhook_signature or not cashfree_client.verify_webhook_signature(raw_body, x_webhook_signature):
        raise HTTPException(status_code=400, detail="Invalid webhook signature")

    payload = await request.json()
    data = payload.get("data", {})
    order_data = data.get("order", {})
    payment_data = data.get("payment", {})

    cf_order_id = order_data.get("order_id") or payment_data.get("order_id")
    cf_payment_id = payment_data.get("cf_payment_id") or payment_data.get("payment_id")
    payment_status = str(payment_data.get("payment_status") or payload.get("type") or "").lower()

    if not cf_order_id:
        return {"status": "ignored", "message": "Webhook does not contain order ID"}

    existing = await registrations_async_collection.find_one(
        {"cf_order_id": cf_order_id},
        {"_id": 0, "payment.mock_mode": 1},
    )
    existing_payment = existing.get("payment", {}) if existing else {}
    existing_mock_mode = bool(existing_payment.get("mock_mode"))

    await registrations_async_collection.update_one(
        {"cf_order_id": cf_order_id},
        {
            "$set": {
                "cf_order_id": cf_order_id,
                "payment": {
                    "gateway": "cashfree",
                    "transaction_id": cf_payment_id,
                    "amount": payment_data.get("payment_amount"),
                    "currency": payment_data.get("payment_currency") or "INR",
                    "status": payment_status or "updated",
                    "mock_mode": existing_mock_mode,
                    "timestamp": utc_now(),
                },
                "webhookPayload": payload,
                "updatedAt": utc_now(),
            },
            "$setOnInsert": {"createdAt": utc_now()},
        },
        upsert=True,
    )

    return {"status": "success"}
