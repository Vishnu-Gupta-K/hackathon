# Spheronix Hackathon 2026 — AWS EC2 Deployment Guide

> Complete step-by-step guide to deploy this FastAPI project on AWS EC2 with **Nginx** (reverse proxy), **Gunicorn + Uvicorn** (ASGI server), and **systemd** (process manager for permanent uptime).

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Launch EC2 Instance](#2-launch-ec2-instance)
3. [Connect to EC2 via SSH](#3-connect-to-ec2-via-ssh)
4. [Install System Dependencies](#4-install-system-dependencies)
5. [Deploy Application Code](#5-deploy-application-code)
6. [Create Production .env File](#6-create-production-env-file)
7. [Configure Gunicorn + systemd Service](#7-configure-gunicorn--systemd-service)
8. [Configure Nginx Reverse Proxy](#8-configure-nginx-reverse-proxy)
9. [Enable HTTPS with Let's Encrypt](#9-enable-https-with-lets-encrypt)
10. [DNS Configuration](#10-dns-configuration)
11. [Google OAuth Setup](#11-google-oauth-setup)
12. [Cashfree Webhook Setup](#12-cashfree-webhook-setup)
13. [Post-Deployment Verification](#13-post-deployment-verification)
14. [Updating the Application](#14-updating-the-application)
15. [Troubleshooting](#15-troubleshooting)

---

## 1. Prerequisites

Before you begin, make sure you have:

- [ ] An **AWS account** with EC2 access
- [ ] A **domain name** (e.g., `hackathon.yourdomain.com`)
- [ ] A **MongoDB Atlas** cluster URI (or self-hosted MongoDB)
- [ ] **Google OAuth** credentials (Client ID & Secret)
- [ ] **Cashfree** production credentials (App ID & Secret Key)
- [ ] **SMTP** credentials for sending emails (e.g., Gmail App Password)
- [ ] An **SSH key pair** (`.pem` file) for EC2 access

---

## 2. Launch EC2 Instance

### 2.1 Create the Instance

1. Go to **AWS Console → EC2 → Launch Instance**
2. Configure:
   - **Name**: `hackathon-prod`
   - **AMI**: `Ubuntu Server 22.04 LTS`
   - **Instance type**: `t3.small` (recommended) or `t2.micro` (free tier / light traffic)
   - **Key pair**: Create or select an existing `.pem` key pair
   - **Storage**: 20 GB gp3 minimum

### 2.2 Configure Security Group

Create a security group with these **inbound rules**:

| Type  | Port | Source              | Purpose        |
|-------|------|---------------------|----------------|
| SSH   | 22   | Your IP only        | Server access  |
| HTTP  | 80   | 0.0.0.0/0           | Web traffic    |
| HTTPS | 443  | 0.0.0.0/0           | SSL traffic    |

> ⚠️ **Never** open SSH (port 22) to `0.0.0.0/0` in production.

### 2.3 Allocate Elastic IP

1. Go to **EC2 → Elastic IPs → Allocate Elastic IP**
2. Associate with your `hackathon-prod` instance
3. Note down this IP — you will use it for DNS

---

## 3. Connect to EC2 via SSH

```bash
# Set permissions on your key file
chmod 400 your-key.pem

# Connect to the server
ssh -i your-key.pem ubuntu@<YOUR_ELASTIC_IP>
```

---

## 4. Install System Dependencies

Run these commands on your EC2 instance:

```bash
# Update system packages
sudo apt update && sudo apt upgrade -y

# Install Python 3, pip, venv, Git, and Nginx
sudo apt install -y python3 python3-pip python3-venv git nginx

# Create a dedicated app user
sudo adduser --disabled-password --gecos "" hackathon

# Create app directory
sudo mkdir -p /opt/hackathon
sudo chown -R hackathon:hackathon /opt/hackathon
```

---

## 5. Deploy Application Code

### 5.1 Clone Repository

```bash
# Switch to the hackathon user
sudo -u hackathon -H bash

# Clone your repo
cd /opt/hackathon
git clone <YOUR_REPO_URL> app
cd app
```

### 5.2 Create Virtual Environment & Install Dependencies

```bash
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

### 5.3 Verify Installation

```bash
# Quick test — should print FastAPI app info, then exit
python -c "from app.main import app; print('App loaded:', app.title)"
```

Then exit the hackathon user shell:

```bash
exit
```

---

## 6. Create Production .env File

Create the file at `/opt/hackathon/app/.env`:

```bash
sudo -u hackathon nano /opt/hackathon/app/.env
```

Paste the following and **fill in your real values**:

```env
# App Configuration
APP_ENV=production
APP_BASE_URL=https://hackathon.yourdomain.com
SERVER_HOST=127.0.0.1
SERVER_PORT=8000
CORS_ORIGINS=https://hackathon.yourdomain.com,https://www.hackathon.yourdomain.com

# Security
SECRET_KEY=<GENERATE_A_LONG_RANDOM_STRING_AT_LEAST_32_CHARS>

# MongoDB
MONGO_URI=mongodb+srv://<user>:<password>@<cluster>.mongodb.net/?appName=<app>
DB_NAME=spheronix_db

# Google OAuth
GOOGLE_CLIENT_ID=<YOUR_GOOGLE_CLIENT_ID>
GOOGLE_CLIENT_SECRET=<YOUR_GOOGLE_CLIENT_SECRET>
GOOGLE_REDIRECT_URI=https://hackathon.yourdomain.com/api/auth/callback

# Cashfree Payment Gateway
CASHFREE_APP_ID=<YOUR_CASHFREE_APP_ID>
CASHFREE_SECRET_KEY=<YOUR_CASHFREE_SECRET_KEY>
CASHFREE_ENVIRONMENT=PRODUCTION
CASHFREE_ALLOW_MOCK_ON_BLOCK=false

# SMTP (for emails)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=465
SMTP_USER=<YOUR_EMAIL@gmail.com>
SMTP_PASSWORD=<YOUR_APP_PASSWORD>
MAIL_FROM=<YOUR_EMAIL@gmail.com>
```

**Lock down permissions** so only the app user can read it:

```bash
sudo chown hackathon:hackathon /opt/hackathon/app/.env
sudo chmod 600 /opt/hackathon/app/.env
```

> 💡 **Tip**: Generate a strong secret key with: `python3 -c "import secrets; print(secrets.token_urlsafe(48))"`

---

## 7. Configure Gunicorn + systemd Service

This ensures your app **runs permanently** and **restarts automatically** on crash or server reboot.

### 7.1 Copy Service File

```bash
sudo cp /opt/hackathon/app/scripts/hackathon.service /etc/systemd/system/hackathon.service
```

The service file contents (already included in `scripts/hackathon.service`):

```ini
[Unit]
Description=Spheronix Hackathon FastAPI Service
After=network.target

[Service]
Type=simple
User=hackathon
Group=www-data
WorkingDirectory=/opt/hackathon/app
EnvironmentFile=/opt/hackathon/app/.env
ExecStart=/opt/hackathon/app/venv/bin/gunicorn -k uvicorn.workers.UvicornWorker --workers 2 --bind 127.0.0.1:8000 --timeout 120 --access-logfile - --error-logfile - app.main:app
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

### 7.2 Enable & Start the Service

```bash
# Reload systemd to pick up the new service
sudo systemctl daemon-reload

# Enable auto-start on boot
sudo systemctl enable hackathon

# Start the service now
sudo systemctl start hackathon

# Check status — should show "active (running)"
sudo systemctl status hackathon
```

### 7.3 View Logs (if needed)

```bash
# Live logs
sudo journalctl -u hackathon -f

# Last 200 lines
sudo journalctl -u hackathon -n 200 --no-pager
```

---

## 8. Configure Nginx Reverse Proxy

Nginx sits in front of Gunicorn, handling HTTP/HTTPS traffic and forwarding it to your app.

### 8.1 Create Nginx Config

```bash
sudo nano /etc/nginx/sites-available/hackathon
```

Paste:

```nginx
server {
    listen 80;
    server_name hackathon.yourdomain.com www.hackathon.yourdomain.com;

    client_max_body_size 10M;

    # Proxy all traffic to Gunicorn
    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 120s;
        proxy_connect_timeout 120s;
    }
}
```

### 8.2 Enable the Site

```bash
# Create symlink to enable the site
sudo ln -sf /etc/nginx/sites-available/hackathon /etc/nginx/sites-enabled/hackathon

# Remove the default site (optional but recommended)
sudo rm -f /etc/nginx/sites-enabled/default

# Test configuration
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

---

## 9. Enable HTTPS with Let's Encrypt

### 9.1 Install Certbot

```bash
sudo apt install -y certbot python3-certbot-nginx
```

### 9.2 Obtain SSL Certificate

```bash
sudo certbot --nginx -d hackathon.yourdomain.com -d www.hackathon.yourdomain.com
```

Follow the prompts:
- Enter your email
- Agree to terms
- Choose to redirect HTTP → HTTPS (recommended)

### 9.3 Verify Auto-Renewal

```bash
sudo systemctl status certbot.timer
sudo certbot renew --dry-run
```

---

## 10. DNS Configuration

Point your domain to the EC2 Elastic IP.

### Using AWS Route 53 (or any DNS provider):

| Record Type | Name                          | Value              |
|-------------|-------------------------------|--------------------|
| A           | hackathon.yourdomain.com      | `<ELASTIC_IP>`     |
| A           | www.hackathon.yourdomain.com  | `<ELASTIC_IP>`     |

> ⏳ DNS propagation can take up to 48 hours, but usually completes within minutes.

---

## 11. Google OAuth Setup

1. Go to **[Google Cloud Console](https://console.cloud.google.com/)**
2. Select or create a project
3. Navigate to **APIs & Services → Credentials**
4. Create an **OAuth 2.0 Client ID** (Web application type)
5. Set:
   - **Authorized JavaScript origins**: `https://hackathon.yourdomain.com`
   - **Authorized redirect URIs**: `https://hackathon.yourdomain.com/api/auth/callback`
6. Copy the **Client ID** and **Client Secret** to your `.env` file

---

## 12. Cashfree Webhook Setup

1. Log in to your **[Cashfree Dashboard](https://merchant.cashfree.com/)**
2. Navigate to **Settings → Webhooks**
3. Set webhook URL to:
   ```
   https://hackathon.yourdomain.com/api/payment/webhook
   ```
4. If Cashfree requires IP allowlisting, add your EC2 Elastic IP

---

## 13. Post-Deployment Verification

Run these checks after deployment:

### ✅ Health Check

```bash
curl -sS https://hackathon.yourdomain.com/api/health
```

Expected response:
```json
{"status": "running", "environment": "production", "timezone": "Asia/Kolkata", ...}
```

### ✅ Frontend

Open `https://hackathon.yourdomain.com` in a browser — static pages should load.

### ✅ OAuth Flow

Click "Login with Google" and verify the full login flow works.

### ✅ Payment Flow

Test a payment via `/api/payment/order` → checkout → `/api/payment/verify`.

### ✅ Email Delivery

Verify that registration confirmation emails are being delivered.

---

## 14. Updating the Application

When you push new code, update the server with:

```bash
# SSH into the server
ssh -i your-key.pem ubuntu@<YOUR_ELASTIC_IP>

# Run the deploy script
sudo -u hackathon -H bash -lc 'cd /opt/hackathon/app && bash scripts/deploy.sh'
```

Or manually:

```bash
sudo -u hackathon -H bash -lc '
  cd /opt/hackathon/app
  git pull origin main
  source venv/bin/activate
  pip install -r requirements.txt
'
sudo systemctl restart hackathon
sudo systemctl status hackathon --no-pager
```

---

## 15. Troubleshooting

| Problem | Command / Fix |
|---------|---------------|
| App won't start | `sudo journalctl -u hackathon -n 200 --no-pager` |
| Nginx errors | `sudo tail -n 100 /var/log/nginx/error.log` |
| Port 8000 in use | `sudo lsof -i :8000` then kill the process |
| OAuth `redirect_uri_mismatch` | Fix `GOOGLE_REDIRECT_URI` in `.env` and Google Console |
| Cashfree 403 | Add server Elastic IP to Cashfree IP allowlist |
| SSL certificate issue | `sudo certbot renew --force-renewal` |
| Service not starting on boot | `sudo systemctl enable hackathon` |

### Useful Commands

```bash
# Restart the app
sudo systemctl restart hackathon

# Restart Nginx
sudo systemctl restart nginx

# Check app status
sudo systemctl status hackathon

# Live app logs
sudo journalctl -u hackathon -f

# Check Nginx config syntax
sudo nginx -t
```

---

## Project Structure (for reference)

```
/opt/hackathon/app/
├── .env                    # Production secrets (NOT in git)
├── .env.example            # Template for .env
├── .gitignore
├── main.py                 # Root entry point
├── gunicorn_conf.py        # Gunicorn configuration
├── requirements.txt        # Python dependencies
├── app/
│   ├── main.py             # FastAPI application
│   ├── core/               # Logging, time utils
│   ├── database/           # MongoDB connection
│   ├── models/             # Pydantic models
│   ├── routers/            # API route handlers
│   └── services/           # Business logic
├── config/
│   └── settings.py         # Environment config via pydantic-settings
├── scripts/
│   ├── hackathon.service   # systemd service file
│   ├── start.sh            # Gunicorn start script
│   └── deploy.sh           # Deployment automation
└── static/                 # Frontend HTML/CSS/JS
    ├── index.html
    ├── css/
    ├── js/
    └── images/
```

---

> 🎉 **Done!** Your Spheronix Hackathon API is now permanently deployed on AWS EC2 with Nginx, Gunicorn, and automatic restart on failure or reboot.
